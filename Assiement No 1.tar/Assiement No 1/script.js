// Q1: Write a program in which you have to create your own biodata details are: your name, email, city,
// education, occupation, phone number, institute name etc. Using template literals and variable using let
// and const and final output is shown in document.write() same as in below:

let MyName = `Yameen`,MyEmail = `abc123@gmail.com`,MyCity = `Karachi`,MyEducation = `Class 9`,MyOccupation = `I Learning Web Developer`,MyPhone = `03183263119`,MyInstitude = `Jawan Pakistan`;

document.writeln(`My Name is :${MyName} <br><br> My Email is :${MyEmail} <br><br> My City :${MyCity} <br><br> My Education :${MyEducation} <br><br> My Occupation :${MyOccupation} <br><br> My Phone Number is :${MyPhone} <br><br> My Institute Name is :${MyInstitude}<br><br><br><br><br>`);


// Q2: Write a program of a basic mark sheet using JavaScript involves let, const variables to store marks
// for different subjects and then calculating the total marks, percentage, and grade based on those marks.
// Using template literals and variable using let and const and final output is shown in document.write().

let MathMarks = 90,EnglishMarks = 80,UrduMarks = 70,ScienceMarks = 60,ComputerMarks = 65,IslamiatMarks = 75;

document.writeln(`Math Marks:${MathMarks}<br><br> English Marks:${EnglishMarks}<br><br> Urdu Marks:${UrduMarks}<br><br> Science Marks:${ScienceMarks}<br><br> Computer Marks:${ComputerMarks}<br><br> Islamiat Maks:${IslamiatMarks}<br><br><br><br><br>`);


// Q3: Students using this below image you have to create each variable keyword apply at least one
// example for tasks executing. I share the output everyone must same as in the image.

var a = "Mohammad";

var abc;

var a = "yameen";

console.log(a);

var a = "Muhammad";

function abc(){
    var a = "yameen";
    console.log(a);
}

abc();